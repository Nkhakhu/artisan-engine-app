package com.tracker.responses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CreatePortfolioResponse {


    @SerializedName("success")
    @Expose
    private boolean success;

    public boolean isSuccess() {
        return success;
    }
}
