package com.tracker.api;

import com.tracker.responses.GetLeadListResponse;
import com.tracker.responses.LeadPurchaseResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface PurchasesAPI {

    @FormUrlEncoded
    @POST("purchases")
    Call<LeadPurchaseResponse> purchaseLead(@Field("lead_id") int leadId,
                                            @Header("Authorization") String token);

    @GET("purchases")
    Call<GetLeadListResponse> getPurchasedLeads(@Header("Authorization") String token);
}
