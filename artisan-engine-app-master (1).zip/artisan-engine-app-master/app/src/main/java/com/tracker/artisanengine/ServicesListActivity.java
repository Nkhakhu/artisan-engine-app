package com.tracker.artisanengine;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PorterDuff;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.tracker.adapters.ArtisanTypeAdapter;
import com.tracker.models.ArtisanType;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import static com.tracker.artisanengine.MainActivity.MY_PERMISSIONS_REQUEST_LOCATION;

public class ServicesListActivity extends AppCompatActivity {

    private ArrayList<ArtisanType> artisanTypes;
    private FusedLocationProviderClient fusedLocationClient;
    private Location mLocation;
    private LocationCallback locationCallback;
    private LocationRequest locationRequest;

    @SuppressLint("RestrictedApi")
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.top_menu, menu);
        if (menu instanceof MenuBuilder) {
            MenuBuilder m = (MenuBuilder) menu;
            m.setOptionalIconsVisible(true);
        }
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_services_list);
        Toolbar toolbar = findViewById(R.id.my_toolbar);
        toolbar.getOverflowIcon().setColorFilter(ContextCompat.getColor(this, R.color.white),
                PorterDuff.Mode.SRC_ATOP);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        artisanTypes = new ArrayList<ArtisanType>();
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        requestLocation();
        getCurrentLocation();
        initialiseComponents();
    }

    private void initialiseComponents() {
        Toast.makeText(getApplicationContext(), "Please Select A Service", Toast.LENGTH_LONG)
                .show();
        ListView artisanTypeListView = findViewById(R.id.artisanTypesList);
        ArtisanTypeAdapter artisanTypeAdapter = new ArtisanTypeAdapter(getApplicationContext(), getArtisanTypes());
        artisanTypeListView.setAdapter(artisanTypeAdapter);
        artisanTypeListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ArtisanType artisanType = (ArtisanType) artisanTypes.get(position);
                Intent locationAndContactActivity = new Intent(getApplicationContext(), LocationAndContactActivity.class);
                locationAndContactActivity.putExtra("ARTISAN_TYPE_ID", artisanType.getArtisanTypeId());
                startActivity(locationAndContactActivity);
            }
        });
    }

    private ArrayList<ArtisanType> getArtisanTypes() {
        ArtisanType plumber = new ArtisanType("Plumbing Services", 1, R.drawable.plumber);
        artisanTypes.add(plumber);
        ArtisanType electrician = new ArtisanType("Electrical Services", 2, R.drawable.electrician);
        artisanTypes.add(electrician);
        ArtisanType painter = new ArtisanType("Painting Services", 3, R.drawable.painter);
        artisanTypes.add(painter);
        ArtisanType carpenter = new ArtisanType("Carpentry Services", 4, R.drawable.carpenter);
        artisanTypes.add(carpenter);
        ArtisanType welding = new ArtisanType("Welding Services", 5, R.drawable.welding);
        artisanTypes.add(welding);
        ArtisanType construction = new ArtisanType("Construction Services", 6, R.drawable.construction);
        artisanTypes.add(construction);
        ArtisanType laundry = new ArtisanType("Locksmith Services", 7, R.drawable.locksmith);
        artisanTypes.add(laundry);
        ArtisanType cleaning = new ArtisanType("Air Con & Refrigerator Services", 8, R.drawable.aircon);
        artisanTypes.add(cleaning);
        ArtisanType furniture = new ArtisanType("Furniture & Upholstery", 9, R.drawable.furniture);
        artisanTypes.add(furniture);
        return artisanTypes;
    }

    protected void requestLocation() {
        locationRequest = LocationRequest.create();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        locationRequest.setInterval(2 * 5000);
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    setCurrentLocation(location);
                    mLocation = location;
                }
            }
        };
    }

    protected void getCurrentLocation() {
        checkLocationPermission();
        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        if (location != null) {
                            setCurrentLocation(location);
                            mLocation = location;
                        } else {
                            Toast.makeText(getApplicationContext(), "Failed to load location!", Toast.LENGTH_LONG)
                                    .show();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.d("MapDemoActivity", "Error trying to get last GPS location");
                e.printStackTrace();
            }
        });
    }

    public boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED) {
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {
                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new AlertDialog.Builder(this)
                        .setTitle("Test")
                        .setMessage("Request")
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(ServicesListActivity.this,
                                        new String[]{
                                                Manifest.permission.ACCESS_FINE_LOCATION
                                        },
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        }).create().show();
            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{
                                Manifest.permission.ACCESS_FINE_LOCATION
                        },
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
            return false;
        } else {
            return true;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        startLocationUpdates();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopLocationUpdates();
    }

    private void stopLocationUpdates() {
        fusedLocationClient.removeLocationUpdates(locationCallback);
    }

    private void setCurrentLocation(Location currentLocation) {
        TextView locationNameTxt = (TextView) findViewById(R.id.currentLocation);
        if(currentLocation != null) {
            Geocoder geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());
            try {
                List<Address> addresses = geocoder.getFromLocation(currentLocation.getLatitude(),
                        currentLocation.getLongitude(), 1);
                if (addresses.size() > 0) {
                    String locationName = addresses.get(0).getLocality();
                    locationNameTxt.setText(locationName);
                    locationNameTxt.setVisibility(View.VISIBLE);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void startLocationUpdates() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    Activity#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for Activity#requestPermissions for more details.
                return;
            }
        }
        fusedLocationClient.requestLocationUpdates(locationRequest,
                locationCallback,
                Looper.getMainLooper());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 &&
                        grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_FINE_LOCATION) ==
                            PackageManager.PERMISSION_GRANTED) {
                        //Request location updates:
                        fusedLocationClient.getLastLocation()
                                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                                    @Override
                                    public void onSuccess(Location location) {
                                        // Got last known location. In some rare situations this can be null.
                                        if (location != null) {
                                            mLocation = location;
                                            setCurrentLocation(location);
                                            Toast.makeText(getApplicationContext(), "Location permission granted!", Toast.LENGTH_LONG)
                                                    .show();
                                        } else {
                                            Toast.makeText(getApplicationContext(), "Failed to load location!", Toast.LENGTH_LONG)
                                                    .show();
                                        }
                                    }
                                });
                    }

                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

        }
    }
}