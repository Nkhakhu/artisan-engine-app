package com.tracker.artisanengine;

import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ListView;

import com.tracker.adapters.LeadListAdapter;
import com.tracker.adapters.PurchasedLeadListAdapter;
import com.tracker.api.LeadAPI;
import com.tracker.api.PurchasesAPI;
import com.tracker.api.RetrofitClientInstance;
import com.tracker.models.Lead;
import com.tracker.responses.GetLeadListResponse;

import java.util.ArrayList;

public class PurchasedLeadsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_purchased_leads);
        getPurchasedLeads();
    }

    private void getPurchasedLeads() {
        Retrofit retrofit = RetrofitClientInstance.getRetrofitInstance();
        PurchasesAPI purchasesAPI = retrofit.create(PurchasesAPI.class);
        SharedPreferences preferencesGet = getSharedPreferences("KEY", Context.MODE_PRIVATE);
        String jwtToken = preferencesGet.getString("tokenKEY", null);
        final ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(PurchasedLeadsActivity.this);
        progressDialog.setMax(100);
        progressDialog.setTitle("Progress");
        progressDialog.setMessage("Fetching data....");
        progressDialog.show();
        purchasesAPI.getPurchasedLeads("Bearer " + jwtToken)
                .enqueue(new Callback<GetLeadListResponse>() {
                    @Override
                    public void onResponse(Call<GetLeadListResponse> call, Response<GetLeadListResponse> response) {
                        if (response.code() == 200) {
                            ArrayList<Lead> leads = new ArrayList<Lead>();
                            leads = response.body().getLeads();
                            ListView purchasedLeadsList = findViewById(R.id.purchasedLeadsList);
                            PurchasedLeadListAdapter purchasedLeadListAdapter = new PurchasedLeadListAdapter(getApplicationContext(), leads);
                            purchasedLeadsList.setEmptyView(findViewById(android.R.id.empty));
                            purchasedLeadsList.setAdapter(purchasedLeadListAdapter);
                            progressDialog.dismiss();
                        }
                    }

                    @Override
                    public void onFailure(Call<GetLeadListResponse> call, Throwable t) {

                    }
                });
    }
}