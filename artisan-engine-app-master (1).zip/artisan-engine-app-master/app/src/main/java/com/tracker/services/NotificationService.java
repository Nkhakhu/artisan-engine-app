package com.tracker.services;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.Intent;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.tracker.artisanengine.BuildConfig;
import com.tracker.artisanengine.GetLeadListActivity;
import com.tracker.artisanengine.R;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

public class NotificationService extends FirebaseMessagingService {

    @Override
    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        final int NOTIFICATION_COLOR = this.getResources().getColor(R.color.blue);
        final Uri NOTIFICATION_SOUND_URI = Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + BuildConfig.APPLICATION_ID + "/" + R.raw.notification_sound);
        Intent intent = new Intent(this, GetLeadListActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_ONE_SHOT);
        String channelId = "Default";
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, channelId)
                .setSmallIcon(R.drawable.notifications_icon)
                .setSound(NOTIFICATION_SOUND_URI)
                .setContentTitle(remoteMessage.getNotification().getTitle())
                .setContentText(remoteMessage.getNotification().getBody())
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setColor(NOTIFICATION_COLOR)
                .setAutoCancel(true).setContentIntent(pendingIntent);
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel mChannel = new NotificationChannel("Default",
                    "Default CHANNEL",
                    NotificationManager.IMPORTANCE_DEFAULT);
            AudioAttributes attributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .build();
            // Configure the notification channel.
            mChannel.setDescription(remoteMessage.getNotification().getBody());
            mChannel.enableLights(true);
            mChannel.enableVibration(true);
            mChannel.setSound(NOTIFICATION_SOUND_URI, attributes); // This is IMPORTANT
            manager.createNotificationChannel(mChannel);
        }
        manager.notify(0, builder.build());
    }
}
