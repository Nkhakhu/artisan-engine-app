package com.tracker.models;

import java.util.Comparator;

public class Suburb {

    public static Comparator<Suburb> ALPHABETICAL_ORDER = new Comparator<Suburb>() {

        @Override
        public int compare(Suburb suburb1, Suburb suburb2) {
            int res = String.CASE_INSENSITIVE_ORDER.compare(suburb1.getSuburbName(), suburb2.getSuburbName());
            if (res == 0) {
                res = suburb1.getSuburbName().compareTo(suburb2.getSuburbName());
            }
            return res;
        }
    };
    private final String suburb_name;
    private final int suburb_id;
    private final String province_name;

    public Suburb(String suburbName, int suburbId, String provinceName) {
        this.suburb_id = suburbId;
        this.suburb_name = suburbName;
        this.province_name = provinceName;
    }

    public String getSuburbName() {
        return this.suburb_name;
    }

    public int getSuburbId() {
        return this.suburb_id;
    }

    public String getProvinceName() {
        return this.province_name;
    }

    @Override
    public String toString() {
        return this.suburb_name;
    }
}
