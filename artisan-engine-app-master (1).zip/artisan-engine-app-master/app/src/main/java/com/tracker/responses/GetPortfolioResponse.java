package com.tracker.responses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.tracker.models.PortfolioItem;

import java.util.ArrayList;

public class GetPortfolioResponse {

    @SerializedName("data")
    @Expose
    private ArrayList<PortfolioItem> portfolioItems;

    public ArrayList<PortfolioItem> getPortfolioItems() {
        return this.portfolioItems;
    }
}
