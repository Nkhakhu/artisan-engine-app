package com.tracker.models;

import java.util.ArrayList;

public class PortfolioItem {

    private String title;
    private String description;
    private ArrayList<PortfolioItemImage> portfolio_images;

    public String getTitle() {
        return this.title;
    }

    public String getDescription() {
        return this.description;
    }

    public ArrayList<PortfolioItemImage> getPortfolioItemImages() {
        return this.portfolio_images;
    }
}
