package com.tracker.responses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.tracker.models.Artisan;
import com.tracker.models.Customer;

public class CustomerRegistrationAndLoginResponse {

    @SerializedName("jwt_token")
    @Expose
    private String token;

    @SerializedName("success")
    @Expose
    private boolean success;

    @SerializedName("customer")
    @Expose
    private Customer customer;

    public String getToken() {
        return token;
    }

    public Customer getCustomer() {
        return this.customer;
    }

    public boolean getSuccess() {
        return success;
    }
}
