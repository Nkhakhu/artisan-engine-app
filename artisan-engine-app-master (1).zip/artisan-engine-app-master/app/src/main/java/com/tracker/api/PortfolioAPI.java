package com.tracker.api;

import com.tracker.responses.CreatePortfolioResponse;
import com.tracker.responses.GetPortfolioResponse;

import java.util.List;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface PortfolioAPI {

    @Multipart
    @POST("portfolios")
    Call<CreatePortfolioResponse> createPortfolio(
            @Part("title") String title,
            @Part("description") String description,
            @Part List<MultipartBody.Part> images,
            @Header("Authorization") String token);

    @GET("portfolios")
    Call<GetPortfolioResponse> getPortfolioItems(@Header("Authorization") String token);
}
