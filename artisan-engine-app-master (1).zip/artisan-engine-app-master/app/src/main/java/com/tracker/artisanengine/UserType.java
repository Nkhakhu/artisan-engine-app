package com.tracker.artisanengine;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

public class UserType extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_type);
        initialiseViewComponents();
    }

    private void initialiseViewComponents() {
        Button submitButton = (Button) findViewById(R.id.submit);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioGroup radioGroup = findViewById(R.id.radio_user_type);
                int id = radioGroup.getCheckedRadioButtonId();
                if(id!=-1) {
                    int radioButtonID = radioGroup.getCheckedRadioButtonId();
                    RadioButton radioButton =
                            (RadioButton) radioGroup.findViewById(radioButtonID);

                    String selectedOption = (String) radioButton.getText();
                    if(selectedOption.equals("Artisan")) {
                        Intent artisanRegistrationIntent = new Intent(getApplicationContext(), ArtisanRegistrationActivity.class);
                        startActivity(artisanRegistrationIntent);
                    } else {
                        Intent customerRegistrationActivity = new Intent(getApplicationContext(), CustomerRegistrationActivity.class);
                        startActivity(customerRegistrationActivity);
                    }
                }
            }
        });
    }
}