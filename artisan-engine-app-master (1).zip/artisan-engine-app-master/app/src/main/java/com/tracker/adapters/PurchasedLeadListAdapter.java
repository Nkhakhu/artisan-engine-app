package com.tracker.adapters;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.tracker.api.PurchasesAPI;
import com.tracker.api.RetrofitClientInstance;
import com.tracker.artisanengine.R;
import com.tracker.models.Lead;
import com.tracker.responses.LeadPurchaseResponse;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

import static com.facebook.FacebookSdk.getApplicationContext;

public class PurchasedLeadListAdapter extends ArrayAdapter<Lead> {

    private final ArrayList<Lead> leads;
    private final Context context;

    public PurchasedLeadListAdapter(Context context, ArrayList<Lead> leads) {
        super(context, 0, leads);
        this.context = context;
        this.leads = leads;
    }

    @Override
    public int getCount() {
        return super.getCount();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.purchased_lead_row_item, parent, false);
        }
        TextView nameTxt = convertView.findViewById(R.id.name);
        TextView emailTxt = convertView.findViewById(R.id.email);
        TextView mobileTxt = convertView.findViewById(R.id.mobile);
        TextView timeLineTxt = convertView.findViewById(R.id.timeline);
        TextView detailsTxt = convertView.findViewById(R.id.details);
        TextView etaTxt = convertView.findViewById(R.id.eta);
        Button buyButton = convertView.findViewById(R.id.buy);
        buyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog confirmActionDialog = new AlertDialog.Builder(v.getRootView().getContext())
                        .setTitle("Confirm")
                        .setMessage("Buying this lead will deduct from your credits, Do you want to continue?")
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                SharedPreferences preferencesGet = context.getSharedPreferences("KEY", Context.MODE_PRIVATE);
                                String jwtToken = preferencesGet.getString("tokenKEY", null);
                                Retrofit retrofit = RetrofitClientInstance.getRetrofitInstance();
                                PurchasesAPI purchasesAPI = retrofit.create(PurchasesAPI.class);
                                final ProgressDialog progressDialog;
                                progressDialog = new ProgressDialog(v.getRootView().getContext());
                                progressDialog.setMax(100);
                                progressDialog.setTitle("Progress");
                                progressDialog.setMessage("Processing Data....");
                                progressDialog.show();
                                purchasesAPI.purchaseLead(leads.get(position).getLeadId(), "Bearer " + jwtToken).enqueue(new Callback<LeadPurchaseResponse>() {
                                    @Override
                                    public void onResponse(Call<LeadPurchaseResponse> call, Response<LeadPurchaseResponse> response) {
                                        if (response.body().getSuccess()) {
                                            Toast.makeText(getApplicationContext(), "Purchase successful!", Toast.LENGTH_LONG)
                                                    .show();
                                            progressDialog.dismiss();
                                        } else {
                                            Toast.makeText(getApplicationContext(), "Purchase failed, please try again", Toast.LENGTH_LONG)
                                                    .show();
                                        }
                                    }

                                    @Override
                                    public void onFailure(Call<LeadPurchaseResponse> call, Throwable t) {

                                    }
                                });
                            }
                        })
                        .setNegativeButton(android.R.string.no, null).show();
            }
        });

        nameTxt.setText(leads.get(position).getCustomer().getUser().getName());
        emailTxt.setText(leads.get(position).getCustomer().getUser().getEmail());
        mobileTxt.setText(leads.get(position).getMobileNumber());
        timeLineTxt.setText(leads.get(position).getCreated_at());
        detailsTxt.setText(leads.get(position).getIssue());
        etaTxt.setText("ETA: " + leads.get(position).getTimeLine());

        return convertView;
    }
}
