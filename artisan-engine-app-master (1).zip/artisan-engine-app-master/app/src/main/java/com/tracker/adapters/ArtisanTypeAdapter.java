package com.tracker.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.tracker.artisanengine.R;
import com.tracker.models.ArtisanType;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class ArtisanTypeAdapter extends ArrayAdapter<ArtisanType> {

    private ArrayList<ArtisanType> artisanTypes;
    private Context context;

    public ArtisanTypeAdapter(@NonNull Context context, ArrayList<ArtisanType> artisanTypes) {
        super(context, 0, artisanTypes);
        this.context = context;
        this.artisanTypes = artisanTypes;
    }

    @Override
    public int getCount() {
        return super.getCount();
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.artisan_type_row, parent, false);
        }
        ImageView artisanTypeImage = convertView.findViewById(R.id.artisan_type_image);
        artisanTypeImage.setImageResource(artisanTypes.get(position).getImage());
        TextView artisanTypeNameTxt = convertView.findViewById(R.id.artisan_type_name);
        artisanTypeNameTxt.setText(artisanTypes.get(position).getArtisanTypeName());
        return convertView;
    }
}
