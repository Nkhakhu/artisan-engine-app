package com.tracker.artisanengine;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.android.gms.location.FusedLocationProviderClient;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private FusedLocationProviderClient fusedLocationClient;
    private Double latitude;
    private Double longitude;
    final private int REQUEST_CODE_ASK_PERMISSIONS = 123;
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences preferencesGet = getSharedPreferences("KEY", Context.MODE_PRIVATE);
        String jwtToken = preferencesGet.getString("tokenKEY", null);
        if (jwtToken == null) {
            Intent userTypeIntent = new Intent(getApplicationContext(), UserType.class);
            startActivity(userTypeIntent);
        } else {
            String userType = preferencesGet.getString("userTypeKEY", null);
            if (userType.equals("Artisan")) {
                Intent dashBoardIntent = new Intent(getApplicationContext(), DashboardActivity.class);
                startActivity(dashBoardIntent);
            } else {
                Intent servicesLitIntent = new Intent(getApplicationContext(), ServicesListActivity.class);
                startActivity(servicesLitIntent);
            }
        }
    }

}