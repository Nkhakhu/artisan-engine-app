package com.tracker.adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import com.tracker.artisanengine.R;
import com.tracker.models.Province;

import java.util.ArrayList;

public class ProvinceSpinnerAdapter extends BaseAdapter implements SpinnerAdapter {

    private ArrayList<Province> dataArray;
    private Context context;

    public ProvinceSpinnerAdapter(Context context, ArrayList<Province> dataArray) {
        this.dataArray = dataArray;
        this.context = context;
    }

    @Override
    public int getCount() {
        return dataArray.size();
    }

    @Override
    public Object getItem(int position) {
        return dataArray.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = View.inflate(context, R.layout.custom_spinner, null);
        TextView textView = (TextView) view.findViewById(R.id.custom_spinner_text);
        textView.setText(dataArray.get(position).getProvinceName());
        return textView;
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {

        View view;

        if (position == 0) {

            view = View.inflate(context, R.layout.custom_spinner_prompt, null);
            TextView textView = (TextView) view.findViewById(R.id.spinner_prompt);
            textView.setText(dataArray.get(position).getProvinceName());
            textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

        } else {
            view = View.inflate(context, R.layout.custom_spinner_dropdown, null);
            TextView textView = (TextView) view.findViewById(R.id.spinner_dropdown);
            textView.setText(dataArray.get(position).getProvinceName());
            textView.setTextColor(Color.BLACK);
        }

        return view;
    }
}
