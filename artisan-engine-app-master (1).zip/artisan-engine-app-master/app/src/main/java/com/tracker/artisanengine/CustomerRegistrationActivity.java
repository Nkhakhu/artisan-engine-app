package com.tracker.artisanengine;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.HttpMethod;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;
import com.tracker.api.CustomerAPI;
import com.tracker.api.RetrofitClientInstance;
import com.tracker.responses.RegistrationResponse;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class CustomerRegistrationActivity extends AppCompatActivity {

    private static final int RC_SIGN_IN = 007;
    private final String FACEBOOK_PROVIDER_NAME = "Facebook";
    private final String GOOGLE_PROVIDER_NAME = "Google";
    private CallbackManager callbackManager;
    private LoginManager loginManager;
    private GoogleSignInClient mGoogleSignInClient;
    private SharedPreferences preferencesPut;
    private SharedPreferences.Editor editor;
    private String firebaseToken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_registration);
        getFirebaseToken();
        SharedPreferences preferencesPut = getSharedPreferences("KEY", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferencesPut.edit();
        //Initialize Facebook SDK
        FacebookSdk.sdkInitialize(CustomerRegistrationActivity.this);
        callbackManager = CallbackManager.Factory.create();
        facebookLogin();
        initializeViews();
        //Google Login
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
    }

    private void getFirebaseToken() {
        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(new OnCompleteListener<String>() {
                    @Override
                    public void onComplete(@NonNull Task<String> task) {
                        if (!task.isSuccessful()) {
                            return;
                        }
                        firebaseToken = task.getResult();
                    }
                });
    }

    protected void initializeViews() {
        Button submitButton = (Button) findViewById(R.id.submit);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText nameEditTxt = (EditText) findViewById(R.id.name);
                EditText emailEditTxt = (EditText) findViewById(R.id.email);
                EditText passwordEditTxt = (EditText) findViewById(R.id.password);
                EditText passwordConfirmTxt = (EditText) findViewById(R.id.confirm_password);
                String name = nameEditTxt.getText().toString();
                String email = emailEditTxt.getText().toString();
                String password = passwordEditTxt.getText().toString();
                String passwordConfirm = passwordConfirmTxt.getText().toString();
                submitApiRequest(name, email, password, passwordConfirm);
            }
        });
        TextView customerLoginLink = findViewById(R.id.customer_login_link);
        customerLoginLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent customerLoginIntent = new Intent(getApplicationContext(), CustomerLoginActivity.class);
                startActivity(customerLoginIntent);
            }
        });
        ImageView mButtonFacebookLink = findViewById(R.id.facebook_registration);
        mButtonFacebookLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginManager.logInWithReadPermissions(CustomerRegistrationActivity.this, Arrays.asList("email", "public_profile"));
            }
        });
        ImageView googleLink = findViewById(R.id.google_registration);
        googleLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent googleSignInIntent = mGoogleSignInClient.getSignInIntent();
                startActivityForResult(googleSignInIntent, RC_SIGN_IN);
            }
        });
    }

    public void facebookLogin() {
        loginManager = LoginManager.getInstance();
        callbackManager = CallbackManager.Factory.create();
        loginManager.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                GraphRequest request = GraphRequest.newMeRequest(loginResult.getAccessToken(),
                        new GraphRequest.GraphJSONObjectCallback() {
                            @Override
                            public void onCompleted(JSONObject object, GraphResponse response) {
                                if (object != null) {
                                    try {
                                        String name = object.getString("name");
                                        String email = object.getString("email");
                                        String facebookId = object.getString("id");
                                        submitSocialRequest(name, email, FACEBOOK_PROVIDER_NAME, facebookId);
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    } finally {
                                        disconnectFromFacebook();
                                    }
                                }
                            }
                        });
                Bundle parameters = new Bundle();
                parameters.putString("fields", "id, name, email, gender");
                request.setParameters(parameters);
                request.executeAsync();
            }

            @Override
            public void onCancel() {
                Log.v("LoginScreen", "---onCancel");
            }

            @Override
            public void onError(FacebookException error) {

            }
        });
    }

    private void handleGoogleSignInResult(GoogleSignInResult result) {
        if (result.isSuccess()) {
            GoogleSignInAccount acct = result.getSignInAccount();
            String name = acct.getDisplayName();
            String googleId = acct.getId();
            String email = acct.getEmail();
            submitSocialRequest(name, email, GOOGLE_PROVIDER_NAME, googleId);
        } else {
            // Signed out, show unauthenticated UI.
        }
    }

    private void submitSocialRequest(String name, String email, String provider, String providerId) {
        Retrofit retrofit = RetrofitClientInstance.getRetrofitInstance();
        CustomerAPI customerAPI = retrofit.create(CustomerAPI.class);
        final ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(CustomerRegistrationActivity.this);
        progressDialog.setMax(100);
        progressDialog.setTitle("Progress");
        progressDialog.setMessage("Submitting data....");
        progressDialog.show();
        customerAPI.registerOrLoginWithSocial(name, email, provider, providerId, firebaseToken)
                .enqueue(new Callback<RegistrationResponse>() {
                    @Override
                    public void onResponse(Call<RegistrationResponse> call, Response<RegistrationResponse> response) {
                        if (response.body().getSuccess()) {
                            preferencesPut = getSharedPreferences("KEY", Context.MODE_PRIVATE);
                            editor = preferencesPut.edit();
                            editor.putString("tokenKEY", response.body().getToken());
                            editor.putString("emailKEY", email);
                            editor.putString("nameKEY", name);
                            editor.putString("userTypeKEY", "Customer");
                            editor.apply();
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), "Registration successful!", Toast.LENGTH_LONG)
                                    .show();
                            Intent serviceListActivity = new Intent(getApplicationContext(), ServicesListActivity.class);
                            startActivity(serviceListActivity);
                        }
                    }

                    @Override
                    public void onFailure(Call<RegistrationResponse> call, Throwable t) {
                        progressDialog.dismiss();
                    }
                });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            handleGoogleSignInResult(result);
        }
    }

    protected void submitApiRequest(String name, String email, String password, String confirmPassword) {
        Retrofit retrofit = RetrofitClientInstance.getRetrofitInstance();
        CustomerAPI customerAPI = retrofit.create(CustomerAPI.class);
        final ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(this);
        progressDialog.setMax(100);
        progressDialog.setTitle("Progress");
        progressDialog.setMessage("Fetching Data....");
        progressDialog.show();
        customerAPI.register(name, email, password, confirmPassword, firebaseToken)
                .enqueue(new Callback<RegistrationResponse>() {
                    @Override
                    public void onResponse(Call<RegistrationResponse> call, Response<RegistrationResponse> response) {
                        if (response.body().getSuccess()) {
                            preferencesPut = getSharedPreferences("KEY", Context.MODE_PRIVATE);
                            editor = preferencesPut.edit();
                            editor.putString("tokenKEY", response.body().getToken());
                            editor.putString("emailKEY", email);
                            editor.putString("nameKEY", name);
                            editor.putString("userTypeKEY", "Customer");
                            editor.apply();
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), "Registration successful!", Toast.LENGTH_LONG)
                                    .show();
                            Intent serviceListActivity = new Intent(getApplicationContext(), ServicesListActivity.class);
                            startActivity(serviceListActivity);
                        }
                    }

                    @Override
                    public void onFailure(Call<RegistrationResponse> call, Throwable t) {

                    }
                });
    }

    public void disconnectFromFacebook() {
        if (AccessToken.getCurrentAccessToken() == null) {
            return;
        }
        new GraphRequest(AccessToken.getCurrentAccessToken(), "/me/permissions/", null, HttpMethod.DELETE,
                new GraphRequest.Callback() {
                    @Override
                    public void onCompleted(GraphResponse graphResponse) {
                        LoginManager.getInstance().logOut();
                    }
                }).executeAsync();
    }
}