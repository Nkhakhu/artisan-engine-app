package com.tracker.artisanengine;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.tracker.api.RequestAPI;
import com.tracker.api.RetrofitClientInstance;
import com.tracker.models.Request;
import com.tracker.responses.RequestSubmissionResponse;

import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class VerificationActivity extends AppCompatActivity {

    private String searchCriteria;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verification);
        Intent verificationIntent = getIntent();
        Bundle bundle = verificationIntent.getBundleExtra("BUNDLE");
        Request requestObj = (Request) bundle.getSerializable("REQUEST_OBJ");
        searchCriteria = verificationIntent.getStringExtra("SEARCH_CRITERIA");
        SharedPreferences preferencesGet = getSharedPreferences("KEY", Context.MODE_PRIVATE);
        String jwtToken = preferencesGet.getString("tokenKEY", null);
        Button submitButton = findViewById(R.id.submit);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText verificationCodeTxt = findViewById(R.id.verification_code);
                String verificationCode = verificationCodeTxt.getText().toString();
                submitRequest(requestObj, verificationCode, jwtToken);
            }
        });
    }

    private void submitRequest(Request requestObj, String verificationCode, String jwtToken) {
        Retrofit retrofit = RetrofitClientInstance.getRetrofitInstance();
        RequestAPI requestAPI = retrofit.create(RequestAPI.class);
        final ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(VerificationActivity.this);
        progressDialog.setMax(100);
        progressDialog.setTitle("Progress");
        progressDialog.setMessage("Submitting Data....");
        progressDialog.show();
        if (searchCriteria.equals("DISTANCE")) {
            requestAPI.searchByLatLng(requestObj.getMobileNumber(),
                    requestObj.getArtisanTypeId(),
                    requestObj.getTimeLine(),
                    requestObj.getIssue(),
                    requestObj.getSearchRadius(),
                    requestObj.getLatitude(),
                    requestObj.getLongitude(),
                    verificationCode,
                    "Bearer " + jwtToken).enqueue(new Callback<RequestSubmissionResponse>() {
                @Override
                public void onResponse(Call<RequestSubmissionResponse> call, Response<RequestSubmissionResponse> response) {
                    if (response.body().getSuccess()) {
                        progressDialog.dismiss();
                        Toast.makeText(getApplicationContext(), "Submission successful!", Toast.LENGTH_LONG)
                                .show();
                        Intent successIntent = new Intent(getApplicationContext(), SuccessActivity.class);
                        startActivity(successIntent);
                    }
                }

                @Override
                public void onFailure(Call<RequestSubmissionResponse> call, Throwable t) {

                }
            });
        } else {
            requestAPI.searchBySuburb(requestObj.getMobileNumber(),
                    requestObj.getArtisanTypeId(),
                    requestObj.getTimeLine(),
                    requestObj.getIssue(),
                    requestObj.getSuburbId(),
                    verificationCode,
                    "Bearer " + jwtToken).enqueue(new Callback<RequestSubmissionResponse>() {
                @Override
                public void onResponse(Call<RequestSubmissionResponse> call, Response<RequestSubmissionResponse> response) {
                    if (response.body().getSuccess()) {
                        progressDialog.dismiss();
                        Toast.makeText(getApplicationContext(), "Submission successful!", Toast.LENGTH_LONG)
                                .show();
                        Intent successIntent = new Intent(getApplicationContext(), SuccessActivity.class);
                        startActivity(successIntent);
                    }
                }

                @Override
                public void onFailure(Call<RequestSubmissionResponse> call, Throwable t) {

                }
            });
        }
    }
}