package com.tracker.adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import com.tracker.artisanengine.R;

public class CustomSpinnerAdapter extends BaseAdapter implements SpinnerAdapter {
    String[] dataArray;
    Context context;

    public CustomSpinnerAdapter(Context context, String[] dataArray) {
        this.dataArray = dataArray;
        this.context = context;
    }

    @Override
    public int getCount() {
        return dataArray.length;
    }

    @Override
    public Object getItem(int position) {
        return dataArray[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = View.inflate(context, R.layout.custom_spinner, null);
        TextView textView = (TextView) view.findViewById(R.id.custom_spinner_text);
        textView.setText(dataArray[position]);
        return textView;
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {

        View view;

        if (position == 0) {

            view = View.inflate(context, R.layout.custom_spinner_prompt, null);
            TextView textView = (TextView) view.findViewById(R.id.spinner_prompt);
            textView.setText(dataArray[position]);
            textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

        } else {
            view = View.inflate(context, R.layout.custom_spinner_dropdown, null);
            TextView textView = (TextView) view.findViewById(R.id.spinner_dropdown);
            textView.setText(dataArray[position]);
            textView.setTextColor(Color.BLACK);
        }

        return view;
    }
}
