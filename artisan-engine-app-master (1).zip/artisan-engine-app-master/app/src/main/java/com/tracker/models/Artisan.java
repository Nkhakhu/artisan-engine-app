package com.tracker.models;

public class Artisan {

    private double latitude;
    private double longitude;
    private String address;
    private ArtisanType artisanType;
    private Suburb suburb;
    private User user;
    private int credits;

    public int getCredits() {
        return credits;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public String getAddress() {
        return address;
    }

    public ArtisanType getArtisanType() {
        return artisanType;
    }

    public Suburb getSuburb() {
        return suburb;
    }

    public User getUser() {
        return user;
    }

}
