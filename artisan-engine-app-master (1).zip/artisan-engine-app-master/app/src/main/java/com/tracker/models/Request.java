package com.tracker.models;

import java.io.Serializable;

public class Request implements Serializable {

    private int artisanTypeId;
    private  String issue;
    private String mobileNumber;
    private int searchRadius;
    private double latitude;
    private double longitude;
    private String timeLine;
    private int suburbId;

    public Request(int artisanTypeId, String issue, String mobileNumber, int searchRadius, double latitude, double longitude, String timeLine) {
        this.artisanTypeId = artisanTypeId;
        this.issue = issue;
        this.mobileNumber = mobileNumber;
        this.searchRadius = searchRadius;
        this.latitude = latitude;
        this.longitude = longitude;
        this.timeLine = timeLine;
    }

    public Request(int artisanTypeId, String issue, String mobileNumber, String timeLine, int suburbId) {
        this.artisanTypeId = artisanTypeId;
        this.issue = issue;
        this.mobileNumber = mobileNumber;
        this.timeLine = timeLine;
        this.suburbId = suburbId;
    }

    public int getSuburbId() {
        return this.suburbId;
    }

    public double getLatitude() {
        return this.latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public int getArtisanTypeId() {
        return artisanTypeId;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public int getSearchRadius() {
        return searchRadius;
    }

    public String getIssue() {
        return issue;
    }

    public String getTimeLine() {
        return timeLine;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public void setArtisanTypeId(int artisanTypeId) {
        this.artisanTypeId = artisanTypeId;
    }

    public void setIssue(String issue) {
        this.issue = issue;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public void setSearchRadius(int searchRadius) {
        this.searchRadius = searchRadius;
    }

    public void setTimeLine(String timeLine) {
        this.timeLine = timeLine;
    }
}
