package com.tracker.artisanengine;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;
import com.tracker.api.ArtisanAPI;
import com.tracker.api.RetrofitClientInstance;
import com.tracker.responses.RegistrationResponse;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class ArtisanLoginActivity extends AppCompatActivity {

    private String firebaseToken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_artisan_login);
        TextView registrationLink = findViewById(R.id.register_link);
        getFirebaseToken();
        registrationLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent artisanRegistrationIntent = new Intent(getApplicationContext(), ArtisanRegistrationActivity.class);
                startActivity(artisanRegistrationIntent);
            }
        });
        Button button = (Button) findViewById(R.id.loginButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText emailTxt = findViewById(R.id.email);
                EditText passwordTxt = findViewById(R.id.password);
                String email = emailTxt.getText().toString();
                String password = passwordTxt.getText().toString();
                login(email, password);
            }
        });
    }

    private void getFirebaseToken() {
        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(new OnCompleteListener<String>() {
                    @Override
                    public void onComplete(@NonNull Task<String> task) {
                        if (!task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), "Failed to retrieve device id", Toast.LENGTH_LONG)
                                    .show();
                            return;
                        }
                        firebaseToken = task.getResult();
                    }
                });
    }

    protected void login(String email, String password) {
        Retrofit retrofit = RetrofitClientInstance.getRetrofitInstance();
        ArtisanAPI artisanAPI = retrofit.create(ArtisanAPI.class);
        final ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(this);
        progressDialog.setMax(100);
        progressDialog.setTitle("Progress");
        progressDialog.setMessage("Fetching Data....");
        progressDialog.show();
        artisanAPI.login(email, password, firebaseToken).enqueue(new Callback<RegistrationResponse>() {
            @Override
            public void onResponse(Call<RegistrationResponse> call, Response<RegistrationResponse> response) {
                if (response.body().getSuccess()) {
                    SharedPreferences preferencesPut = getSharedPreferences("KEY", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferencesPut.edit();
                    editor.putString("tokenKEY", response.body().getToken());
                    editor.putString("emailKEY", email);
                    editor.putString("nameKEY", response.body().getArtisan().getUser().getName());
                    editor.putString("creditsKEY", Integer.toString(response.body().getArtisan().getCredits()));
                    editor.putString("userTypeKEY", "Artisan");
                    editor.putBoolean("done", true);
                    editor.apply();
                    progressDialog.dismiss();
                    Intent dashBoardIntent = new Intent(getApplicationContext(), DashboardActivity.class);
                    startActivity(dashBoardIntent);
                } else {
                    Toast.makeText(getApplicationContext(), "Login failed, wrong username or password", Toast.LENGTH_LONG)
                            .show();
                }
            }

            @Override
            public void onFailure(Call<RegistrationResponse> call, Throwable t) {

            }
        });
    }
}