package com.tracker.responses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.tracker.models.Lead;

import java.util.ArrayList;

public class GetLeadListResponse {
    @SerializedName("data")
    @Expose
    private ArrayList<Lead> leads;

    public ArrayList<Lead> getLeads() {
        return leads;
    }
}
