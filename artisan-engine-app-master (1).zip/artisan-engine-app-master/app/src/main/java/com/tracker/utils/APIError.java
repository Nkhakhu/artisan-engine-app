package com.tracker.utils;

public class APIError {

    public String[] errors;

    public String[] getErrors() {
        return this.errors;
    }
}
