package com.tracker.api;

import com.tracker.responses.RequestSubmissionResponse;
import com.tracker.responses.VerificationResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface RequestAPI {

    @FormUrlEncoded
    @POST("leads")
    Call<RequestSubmissionResponse> searchByLatLng(@Field("mobile_number") String mobileNumber,
                                                   @Field("artisan_type_id") int artisanTypeId,
                                                   @Field("expected_timeline") String time,
                                                   @Field("issue") String issue,
                                                   @Field("search_radius") int searchRadius,
                                                   @Field("latitude") double latitude,
                                                   @Field("longitude") double longitude,
                                                   @Field("verification_code") String verificationCode,
                                                   @Header("Authorization") String token);

    @FormUrlEncoded
    @POST("leads")
    Call<RequestSubmissionResponse> searchBySuburb(@Field("mobile_number") String mobileNumber,
                                                   @Field("artisan_type_id") int artisanTypeId,
                                                   @Field("expected_timeline") String time,
                                                   @Field("issue") String issue,
                                                   @Field("suburb_id") int suburbId,
                                                   @Field("verification_code") String verificationCode,
                                                   @Header("Authorization") String token);

    @FormUrlEncoded
    @POST("verify")
    Call<VerificationResponse> verifyMobileNumber(@Field("mobile_phone") String mobileNumber);
}
