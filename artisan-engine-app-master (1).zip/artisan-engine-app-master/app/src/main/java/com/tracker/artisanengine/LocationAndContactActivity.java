package com.tracker.artisanengine;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PorterDuff;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.text.Editable;
import android.text.Selection;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.tracker.adapters.CustomSpinnerAdapter;
import com.tracker.adapters.ProvinceSpinnerAdapter;
import com.tracker.adapters.SuburbSpinnerAdapter;
import com.tracker.api.ProvincesAPI;
import com.tracker.api.RequestAPI;
import com.tracker.api.RetrofitClientInstance;
import com.tracker.models.Province;
import com.tracker.models.Request;
import com.tracker.models.Suburb;
import com.tracker.responses.ProvincesList;
import com.tracker.responses.VerificationResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

import static com.tracker.artisanengine.MainActivity.MY_PERMISSIONS_REQUEST_LOCATION;

public class LocationAndContactActivity extends AppCompatActivity {

    private final int HTTP_STATUS_CREATED = 201;
    private int searchRadius = 25;
    private int artisanTypeId;
    private FusedLocationProviderClient fusedLocationClient;
    private Location mLocation;
    private LocationCallback locationCallback;
    private LocationRequest locationRequest;
    private String issue = "";
    private ArrayList<Province> provinces;
    private ArrayList<Suburb> suburbs;
    private Spinner provincesSpinner, suburbsSpinner;


    @SuppressLint("RestrictedApi")
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.top_menu, menu);
        if (menu instanceof MenuBuilder) {
            MenuBuilder m = (MenuBuilder) menu;
            m.setOptionalIconsVisible(true);
        }
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_and_contact);
        Toolbar toolbar = findViewById(R.id.my_toolbar);
        toolbar.getOverflowIcon().setColorFilter(ContextCompat.getColor(this, R.color.white),
                PorterDuff.Mode.SRC_ATOP);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        requestLocation();
        getCurrentLocation();
        Intent intent = getIntent();
        artisanTypeId = intent.getIntExtra("ARTISAN_TYPE_ID", 0);
        initializeViews();
        getProvinces();
    }

    private void getProvinces() {
        provinces = new ArrayList<Province>();
        suburbs = new ArrayList<Suburb>();
        Retrofit retrofit = RetrofitClientInstance.getRetrofitInstance();
        ProvincesAPI provincesAPI = retrofit.create(ProvincesAPI.class);
        final ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(LocationAndContactActivity.this);
        progressDialog.setMax(100);
        progressDialog.setTitle("Progress");
        progressDialog.setMessage("Fetching Data....");
        progressDialog.show();
        provincesAPI.getProvinces().enqueue(new Callback<ProvincesList>() {
            @Override
            public void onResponse(Call<ProvincesList> call, Response<ProvincesList> response) {
                Spinner provincesSpinner = findViewById(R.id.provinces);
                provinces = response.body().getProvinces();
                Collections.sort(provinces, Province.ALPHABETICAL_ORDER);
                provinces.add(0, new Province("Select Your Province"));
                ProvinceSpinnerAdapter provinceSpinnerAdapter = new ProvinceSpinnerAdapter(getApplicationContext(), provinces) {
                    @Override
                    public boolean isEnabled(int position) {
                        return position != 0;
                    }
                };
                provincesSpinner.setAdapter(provinceSpinnerAdapter);
                progressDialog.dismiss();
            }

            @Override
            public void onFailure(Call<ProvincesList> call, Throwable t) {
                progressDialog.dismiss();
            }
        });
    }

    private void setupSpinner(Spinner spinner, int spinnerArray) {
        String[] array = getApplicationContext().getResources().getStringArray(spinnerArray);
        CustomSpinnerAdapter customSpinnerAdapter = new CustomSpinnerAdapter(this, array) {
            @Override
            public boolean isEnabled(int position) {
                return position != 0;
            }
        };
        spinner.setAdapter(customSpinnerAdapter);
    }

    private void initializeViews() {
        Spinner issuesSpinner = findViewById(R.id.issues_spinner);
        provincesSpinner = findViewById(R.id.provinces);
        suburbsSpinner = findViewById(R.id.suburbs);
        provincesSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Province selectedProvince = provinces.get(position);
                ArrayList<Suburb> suburbs = new ArrayList<Suburb>();
                suburbs = selectedProvince.getSuburbs();
                Collections.sort(suburbs, Suburb.ALPHABETICAL_ORDER);
                suburbs.add(0, new Suburb("Select Your Locality", 0, ""));
                SuburbSpinnerAdapter suburbSpinnerAdapter = new SuburbSpinnerAdapter(getApplicationContext(), suburbs) {
                    @Override
                    public boolean isEnabled(int position) {
                        return position != 0;
                    }
                };
                suburbsSpinner.setAdapter(suburbSpinnerAdapter);
                if (position > 0) {
                    suburbsSpinner.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        switch (artisanTypeId) {
            case 1:
                setupSpinner(issuesSpinner, R.array.plumbing_issues);
                break;
            case 2:
                setupSpinner(issuesSpinner, R.array.electrical_issues);
                break;
            case 3:
                setupSpinner(issuesSpinner, R.array.painting_services);
                break;
            case 4:
                setupSpinner(issuesSpinner, R.array.carpentry_services);
                break;
            case 5:
                setupSpinner(issuesSpinner, R.array.welding_services);
                break;
            case 6:
                setupSpinner(issuesSpinner, R.array.construction_services);
                break;
            case 7:
                setupSpinner(issuesSpinner, R.array.locksmith_services);
                break;
            case 8:
                setupSpinner(issuesSpinner, R.array.aircon_and_refrigrator_service);
                break;
            case 9:
                setupSpinner(issuesSpinner, R.array.furniture_and_upholstery_services);
                break;
        }
        EditText issueTxt = findViewById(R.id.issues);
        issuesSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (issuesSpinner.getSelectedItem().toString().equals("Other")) {
                    issueTxt.setFocusableInTouchMode(true);
                    Toast.makeText(getApplicationContext(), "Describe your requirements int the description box", Toast.LENGTH_LONG)
                            .show();
                } else {
                    issueTxt.setFocusable(false);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        Spinner timeLineSpinner = findViewById(R.id.timeline);
        setupSpinner(timeLineSpinner, R.array.timelines);
        TextView provincesTextView1 = findViewById(R.id.provincesTextView1);
        SeekBar distanceSeekBar = findViewById(R.id.distanceSeekBar);
        TextView distanceTextView = findViewById(R.id.distanceTextView);
        TextView distanceTextView1 = findViewById(R.id.distanceTextView1);
        RadioButton provincesRadio = findViewById(R.id.radioProvince);
        Spinner suburbsSpinner = findViewById(R.id.suburbs);
        distanceSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int progressChangedValue = 25;

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progressChangedValue = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                distanceTextView.setText("Within 25 KM");
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                distanceTextView.setText("Within " + progressChangedValue + " KM");
                searchRadius = progressChangedValue;
            }
        });

        View.OnClickListener provincesRadioButtonOnClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                provincesSpinner.setVisibility(View.VISIBLE);
                provincesTextView1.setVisibility(View.VISIBLE);
                distanceSeekBar.setVisibility(View.INVISIBLE);
                distanceTextView.setVisibility(View.INVISIBLE);
                distanceTextView1.setVisibility(View.INVISIBLE);
                if (provincesSpinner.getSelectedItemPosition() > 0) {
                    suburbsSpinner.setVisibility(View.VISIBLE);
                }
            }
        };
        View.OnClickListener currentLocationRadioButtonClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                provincesSpinner.setVisibility(View.INVISIBLE);
                provincesTextView1.setVisibility(View.INVISIBLE);
                distanceSeekBar.setVisibility(View.VISIBLE);
                distanceTextView.setVisibility(View.VISIBLE);
                distanceTextView1.setVisibility(View.VISIBLE);
                suburbsSpinner.setVisibility(View.INVISIBLE);
            }
        };
        EditText phoneNumberTxt = findViewById(R.id.mobile_number);
        phoneNumberTxt.setText("+27");
        Selection.setSelection(phoneNumberTxt.getText(), phoneNumberTxt.getText().length());
        phoneNumberTxt.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!s.toString().startsWith("+27")) {
                    phoneNumberTxt.setText("+27");
                    Selection.setSelection(phoneNumberTxt.getText(), phoneNumberTxt
                            .getText().length());

                }

            }

        });
        RadioButton currentLocationRadio = findViewById(R.id.radioCurrentLocation);
        provincesRadio.setOnClickListener(provincesRadioButtonOnClickListener);
        currentLocationRadio.setOnClickListener(currentLocationRadioButtonClickListener);
        Button submitButton = findViewById(R.id.submit);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mobileNumber = phoneNumberTxt.getText().toString();
                if (mobileNumber.length() < 12) {
                    Toast.makeText(getApplicationContext(),
                            "Please enter a Valid Mobile Phone Number", Toast.LENGTH_LONG)
                            .show();
                    return;
                }
                if (issueTxt.isFocusableInTouchMode()) {
                    issue = issueTxt.getText().toString();
                } else {
                    issue = issuesSpinner.getSelectedItem().toString();
                }
                if (issue.equals("") || issuesSpinner.getSelectedItemPosition() == 0) {
                    Toast.makeText(getApplicationContext(),
                            "Please specify your issue or service required", Toast.LENGTH_LONG)
                            .show();
                    return;
                }

                if (timeLineSpinner.getSelectedItemPosition() == 0) {
                    Toast.makeText(getApplicationContext(),
                            "Please specify your expected project commencement time", Toast.LENGTH_LONG)
                            .show();
                    return;
                }
                String timeLine = timeLineSpinner.getSelectedItem().toString();
                if (currentLocationRadio.isChecked()) {
                    Retrofit retrofit = RetrofitClientInstance.getRetrofitInstance();
                    RequestAPI requestAPI = retrofit.create(RequestAPI.class);
                    final ProgressDialog progressDialog;
                    progressDialog = new ProgressDialog(LocationAndContactActivity.this);
                    progressDialog.setMax(100);
                    progressDialog.setTitle("Progress");
                    progressDialog.setMessage("Submitting Data....");
                    progressDialog.show();
                    requestAPI.verifyMobileNumber(mobileNumber)
                            .enqueue(new Callback<VerificationResponse>() {
                                @Override
                                public void onResponse(Call<VerificationResponse> call, Response<VerificationResponse> response) {
                                    if (response.code() == HTTP_STATUS_CREATED) {
                                        Request request = new Request(artisanTypeId, issue, mobileNumber, searchRadius, mLocation.getLatitude(), mLocation.getLongitude(), timeLine);
                                        Intent verificationIntent = new Intent(getApplicationContext(), VerificationActivity.class);
                                        Bundle bundle = new Bundle();
                                        bundle.putSerializable("REQUEST_OBJ", request);
                                        verificationIntent.putExtra("BUNDLE", bundle);
                                        verificationIntent.putExtra("SEARCH_CRITERIA", "DISTANCE");
                                        startActivity(verificationIntent);
                                    } else if (response.code() == 422) {
                                        progressDialog.dismiss();
                                        Toast.makeText(getApplicationContext(), "Please enter a valid Mobile Phone Number", Toast.LENGTH_LONG)
                                                .show();
                                    }
                                }

                                @Override
                                public void onFailure(Call<VerificationResponse> call, Throwable t) {

                                }
                            });
                } else {
                    Suburb suburb = (Suburb) suburbsSpinner.getSelectedItem();
                    Retrofit retrofit = RetrofitClientInstance.getRetrofitInstance();
                    RequestAPI requestAPI = retrofit.create(RequestAPI.class);
                    final ProgressDialog progressDialog;
                    progressDialog = new ProgressDialog(LocationAndContactActivity.this);
                    progressDialog.setMax(100);
                    progressDialog.setTitle("Progress");
                    progressDialog.setMessage("Submitting Data....");
                    progressDialog.show();
                    requestAPI.verifyMobileNumber(mobileNumber)
                            .enqueue(new Callback<VerificationResponse>() {
                                @Override
                                public void onResponse(Call<VerificationResponse> call, Response<VerificationResponse> response) {
                                    if (response.code() == HTTP_STATUS_CREATED) {
                                        Request request = new Request(artisanTypeId, issue, mobileNumber, timeLine, suburb.getSuburbId());
                                        Intent verificationIntent = new Intent(getApplicationContext(), VerificationActivity.class);
                                        Bundle bundle = new Bundle();
                                        bundle.putSerializable("REQUEST_OBJ", request);
                                        verificationIntent.putExtra("BUNDLE", bundle);
                                        verificationIntent.putExtra("SEARCH_CRITERIA", "SUBURB");
                                        startActivity(verificationIntent);
                                    }
                                }

                                @Override
                                public void onFailure(Call<VerificationResponse> call, Throwable t) {

                                }
                            });
                }
            }
        });
    }

    protected void requestLocation() {
        locationRequest = LocationRequest.create();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        locationRequest.setInterval(2 * 5000);
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    mLocation = location;
                    setCurrentLocation(location);
                }
            }
        };
    }

    protected void getCurrentLocation() {
        checkLocationPermission();
        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        if (location != null) {
                            mLocation = location;
                            setCurrentLocation(location);
                        } else {
                            Toast.makeText(getApplicationContext(), "Failed to load location!", Toast.LENGTH_LONG)
                                    .show();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.d("MapDemoActivity", "Error trying to get last GPS location");
                e.printStackTrace();
            }
        });
    }

    public boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED) {
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {
                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new AlertDialog.Builder(this)
                        .setTitle("Test")
                        .setMessage("Request")
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(LocationAndContactActivity.this,
                                        new String[]{
                                                Manifest.permission.ACCESS_FINE_LOCATION
                                        },
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        }).create().show();
            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{
                                Manifest.permission.ACCESS_FINE_LOCATION
                        },
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
            return false;
        } else {
            return true;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        startLocationUpdates();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopLocationUpdates();
    }

    private void stopLocationUpdates() {
        fusedLocationClient.removeLocationUpdates(locationCallback);
    }

    private void startLocationUpdates() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    Activity#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for Activity#requestPermissions for more details.
                return;
            }
        }
        fusedLocationClient.requestLocationUpdates(locationRequest,
                locationCallback,
                Looper.getMainLooper());
    }

    private void setCurrentLocation(Location currentLocation) {
        TextView locationNameTxt = findViewById(R.id.currentLocation);
        if (currentLocation != null) {
            Geocoder geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());
            try {
                List<Address> addresses = geocoder.getFromLocation(currentLocation.getLatitude(),
                        currentLocation.getLongitude(), 1);
                if (addresses.size() > 0) {
                    String locationName = addresses.get(0).getLocality() + ", " + addresses.get(0).getAdminArea();
                    locationNameTxt.setText(locationName);
                    locationNameTxt.setVisibility(View.VISIBLE);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 &&
                        grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_FINE_LOCATION) ==
                            PackageManager.PERMISSION_GRANTED) {
                        //Request location updates:
                        fusedLocationClient.getLastLocation()
                                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                                    @Override
                                    public void onSuccess(Location location) {
                                        // Got last known location. In some rare situations this can be null.
                                        if (location != null) {
                                            mLocation = location;
                                            setCurrentLocation(location);
                                            Toast.makeText(getApplicationContext(), "Location permission granted!", Toast.LENGTH_LONG)
                                                    .show();
                                        } else {
                                            Toast.makeText(getApplicationContext(), "Failed to load location!", Toast.LENGTH_LONG)
                                                    .show();
                                        }
                                    }
                                });
                    }

                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

        }
    }
}