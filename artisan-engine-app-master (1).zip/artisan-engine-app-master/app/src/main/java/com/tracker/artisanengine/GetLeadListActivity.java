package com.tracker.artisanengine;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ListView;

import com.tracker.adapters.LeadListAdapter;
import com.tracker.api.LeadAPI;
import com.tracker.api.RetrofitClientInstance;
import com.tracker.models.Lead;
import com.tracker.responses.GetLeadListResponse;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class GetLeadListActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_lead_list);
        getLeads();
    }

    private void getLeads() {
        Retrofit retrofit = RetrofitClientInstance.getRetrofitInstance();
        LeadAPI leadAPI = retrofit.create(LeadAPI.class);
        SharedPreferences preferencesGet = getSharedPreferences("KEY", Context.MODE_PRIVATE);
        String jwtToken = preferencesGet.getString("tokenKEY", null);
        final ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(GetLeadListActivity.this);
        progressDialog.setMax(100);
        progressDialog.setTitle("Progress");
        progressDialog.setMessage("Fetching data....");
        progressDialog.show();
        leadAPI.getLeads("Bearer " + jwtToken)
                .enqueue(new Callback<GetLeadListResponse>() {
                    @Override
                    public void onResponse(Call<GetLeadListResponse> call, Response<GetLeadListResponse> response) {
                        if (response.code() == 200) {
                            ArrayList<Lead> leads = new ArrayList<Lead>();
                            leads = response.body().getLeads();
                            ListView leadListView = findViewById(R.id.leadList);
                            LeadListAdapter leadListAdapter = new LeadListAdapter(getApplicationContext(), leads);
                            leadListView.setEmptyView(findViewById(android.R.id.empty));
                            leadListView.setAdapter(leadListAdapter);
                            progressDialog.dismiss();
                        }
                    }

                    @Override
                    public void onFailure(Call<GetLeadListResponse> call, Throwable t) {

                    }
                });
    }
}