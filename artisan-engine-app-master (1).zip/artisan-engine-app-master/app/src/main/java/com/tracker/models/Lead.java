package com.tracker.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Lead {

    private String mobile_number;

    @SerializedName("expected_timeline")
    @Expose
    private String expected_timeline;

    @SerializedName("issue")
    @Expose
    private String issue;

    @SerializedName("customer")
    @Expose
    private Customer customer;

    @SerializedName("latitude")
    @Expose
    private double latitude;

    @SerializedName("longitude")
    @Expose
    private double longitude;

    private int lead_id;

    public int getLeadId () {
        return this.lead_id;
    }

    private String created_at;

    public String getCreated_at() {
        return this.created_at;
    }

    public String getTimeLine() {
        return expected_timeline;
    }

    public String getIssue() {
        return issue;
    }

    public String getMobileNumber() {
        return mobile_number;
    }

    public double getLongitude() {
        return longitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public Customer getCustomer()
    {
        return this.customer;
    }
}
