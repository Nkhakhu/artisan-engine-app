package com.tracker.artisanengine;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.HttpMethod;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;
import com.tracker.api.CustomerAPI;
import com.tracker.api.RetrofitClientInstance;
import com.tracker.responses.CustomerRegistrationAndLoginResponse;
import com.tracker.responses.RegistrationResponse;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class CustomerLoginActivity extends AppCompatActivity {

    private static final int RC_SIGN_IN = 007;
    private CallbackManager callbackManager;
    private LoginManager loginManager;
    private GoogleSignInClient mGoogleSignInClient;
    private SharedPreferences preferencesPut;
    private SharedPreferences.Editor editor;
    private String firebaseToken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_login);
        getFirebaseToken();
        initialiseComponents();
        FacebookSdk.sdkInitialize(CustomerLoginActivity.this);
        callbackManager = CallbackManager.Factory.create();
        facebookLogin();
        //Google Login
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            handleGoogleSignInResult(result);
        }
    }

    private void getFirebaseToken() {
        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(new OnCompleteListener<String>() {
                    @Override
                    public void onComplete(@NonNull Task<String> task) {
                        if (!task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), "Unable to get device token!", Toast.LENGTH_LONG)
                                    .show();
                            return;
                        }
                        firebaseToken = task.getResult();
                    }
                });
    }

    protected void initialiseComponents() {
        TextView registerTxt = findViewById(R.id.register_link);
        registerTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent customerRegistrationIntent = new Intent(getApplicationContext(), CustomerRegistrationActivity.class);
                startActivity(customerRegistrationIntent);
            }
        });
        ImageView mButtonFacebookLink = findViewById(R.id.facebook_login);
        mButtonFacebookLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginManager.logInWithReadPermissions(CustomerLoginActivity.this, Arrays.asList("email", "public_profile"));
            }
        });
        ImageView googleLink = findViewById(R.id.google_login);
        googleLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent googleSignInIntent = mGoogleSignInClient.getSignInIntent();
                startActivityForResult(googleSignInIntent, RC_SIGN_IN);
            }
        });
        Button loginButton = findViewById(R.id.loginButton);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText emailTxt = findViewById(R.id.email);
                EditText passwordTxt = findViewById(R.id.password);
                String email = emailTxt.getText().toString();
                if (email.equals("")) {
                    Toast.makeText(getApplicationContext(), "Enter a valid email!", Toast.LENGTH_LONG)
                            .show();
                    return;
                }
                String password = passwordTxt.getText().toString();
                if (password.equals("")) {
                    Toast.makeText(getApplicationContext(), "Enter your password!", Toast.LENGTH_LONG)
                            .show();
                    return;
                }

                login(email, password, firebaseToken);
            }
        });
    }

    private void handleGoogleSignInResult(GoogleSignInResult result) {
        if (result.isSuccess()) {
            GoogleSignInAccount acct = result.getSignInAccount();
            String name = acct.getDisplayName();
            String googleId = acct.getId();
            String email = acct.getEmail();
            Retrofit retrofit = RetrofitClientInstance.getRetrofitInstance();
            CustomerAPI customerAPI = retrofit.create(CustomerAPI.class);
            final ProgressDialog progressDialog;
            progressDialog = new ProgressDialog(CustomerLoginActivity.this);
            progressDialog.setMax(100);
            progressDialog.setTitle("Progress");
            progressDialog.setMessage("Submitting data....");
            progressDialog.show();
            customerAPI.registerOrLoginWithSocial(name, email, "Google", googleId, firebaseToken)
                    .enqueue(new Callback<RegistrationResponse>() {
                        @Override
                        public void onResponse(Call<RegistrationResponse> call, Response<RegistrationResponse> response) {
                            if (response.body().getSuccess()) {
                                preferencesPut = getSharedPreferences("KEY", Context.MODE_PRIVATE);
                                editor = preferencesPut.edit();
                                editor.putString("tokenKEY", response.body().getToken());
                                editor.putString("emailKEY", email);
                                editor.putString("nameKEY", name);
                                editor.putString("userTypeKEY", "Customer");
                                editor.apply();
                                progressDialog.dismiss();
                                Toast.makeText(getApplicationContext(), "Login successful!", Toast.LENGTH_LONG)
                                        .show();
                                Intent serviceListActivity = new Intent(getApplicationContext(), ServicesListActivity.class);
                                startActivity(serviceListActivity);
                            }
                        }

                        @Override
                        public void onFailure(Call<RegistrationResponse> call, Throwable t) {

                        }
                    });
        } else {
            // Signed out, show unauthenticated UI.
        }
    }

    /**
     * @param email
     * @param password
     * @param firebaseToken
     */
    private void login(String email, String password, String firebaseToken) {
        Retrofit retrofit = RetrofitClientInstance.getRetrofitInstance();
        CustomerAPI customerAPI = retrofit.create(CustomerAPI.class);
        final ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(CustomerLoginActivity.this);
        progressDialog.setMax(100);
        progressDialog.setTitle("Progress");
        progressDialog.setMessage("Submitting data....");
        progressDialog.show();
        customerAPI.login(email, password, firebaseToken).enqueue(new Callback<CustomerRegistrationAndLoginResponse>() {
            @Override
            public void onResponse(Call<CustomerRegistrationAndLoginResponse> call, Response<CustomerRegistrationAndLoginResponse> response) {
                if (response.code() == 200) {
                    if (response.body().getSuccess()) {
                        preferencesPut = getSharedPreferences("KEY", Context.MODE_PRIVATE);
                        editor = preferencesPut.edit();
                        editor.putString("tokenKEY", response.body().getToken());
                        editor.putString("emailKEY", email);
                        editor.putString("nameKEY", response.body().getCustomer().getUser().getName());
                        editor.putString("userTypeKEY", "Customer");
                        editor.apply();
                        progressDialog.dismiss();
                        Toast.makeText(getApplicationContext(), "Login successful!", Toast.LENGTH_LONG)
                                .show();
                        Intent serviceListActivity = new Intent(getApplicationContext(), ServicesListActivity.class);
                        startActivity(serviceListActivity);
                    }
                } else if (response.code() == 422) {
                    Toast.makeText(getApplicationContext(), "Login failed! Wrong data format", Toast.LENGTH_LONG)
                            .show();
                    progressDialog.dismiss();
                } else {
                    progressDialog.dismiss();
                    Toast.makeText(getApplicationContext(), "Login unsuccessful! Wrong username or password", Toast.LENGTH_LONG)
                            .show();
                }
            }

            @Override
            public void onFailure(Call<CustomerRegistrationAndLoginResponse> call, Throwable t) {
                progressDialog.dismiss();
            }
        });
    }

    public void facebookLogin() {
        loginManager = LoginManager.getInstance();
        callbackManager = CallbackManager.Factory.create();
        loginManager.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                GraphRequest request = GraphRequest.newMeRequest(loginResult.getAccessToken(),
                        new GraphRequest.GraphJSONObjectCallback() {
                            @Override
                            public void onCompleted(JSONObject object, GraphResponse response) {
                                if (object != null) {
                                    try {
                                        String name = object.getString("name");
                                        String email = object.getString("email");
                                        String facebookId = object.getString("id");
                                        Retrofit retrofit = RetrofitClientInstance.getRetrofitInstance();
                                        CustomerAPI customerAPI = retrofit.create(CustomerAPI.class);
                                        final ProgressDialog progressDialog;
                                        progressDialog = new ProgressDialog(CustomerLoginActivity.this);
                                        progressDialog.setMax(100);
                                        progressDialog.setTitle("Progress");
                                        progressDialog.setMessage("Submitting data....");
                                        progressDialog.show();
                                        customerAPI.registerOrLoginWithSocial(name, email, "Facebook", facebookId, firebaseToken)
                                                .enqueue(new Callback<RegistrationResponse>() {
                                                    @Override
                                                    public void onResponse(Call<RegistrationResponse> call, Response<RegistrationResponse> response) {
                                                        if (response.body().getSuccess()) {
                                                            preferencesPut = getSharedPreferences("KEY", Context.MODE_PRIVATE);
                                                            editor = preferencesPut.edit();
                                                            editor.putString("tokenKEY", response.body().getToken());
                                                            editor.putString("emailKEY", email);
                                                            editor.putString("nameKEY", name);
                                                            editor.putString("userTypeKEY", "Customer");
                                                            editor.apply();
                                                            progressDialog.dismiss();
                                                            Toast.makeText(getApplicationContext(), "Login successful!", Toast.LENGTH_LONG)
                                                                    .show();
                                                            Intent serviceListActivity = new Intent(getApplicationContext(), ServicesListActivity.class);
                                                            startActivity(serviceListActivity);
                                                        }
                                                    }

                                                    @Override
                                                    public void onFailure(Call<RegistrationResponse> call, Throwable t) {

                                                    }
                                                });
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    } finally {
                                        disconnectFromFacebook();
                                    }
                                }
                            }
                        });
                Bundle parameters = new Bundle();
                parameters.putString("fields", "id, name, email, gender");
                request.setParameters(parameters);
                request.executeAsync();
            }

            @Override
            public void onCancel() {
                Log.v("LoginScreen", "---onCancel");
            }

            @Override
            public void onError(FacebookException error) {

            }
        });
    }

    public void disconnectFromFacebook() {
        if (AccessToken.getCurrentAccessToken() == null) {
            return;
        }
        new GraphRequest(AccessToken.getCurrentAccessToken(), "/me/permissions/", null, HttpMethod.DELETE,
                new GraphRequest.Callback() {
                    @Override
                    public void onCompleted(GraphResponse graphResponse) {
                        LoginManager.getInstance().logOut();
                    }
                }).executeAsync();
    }
}