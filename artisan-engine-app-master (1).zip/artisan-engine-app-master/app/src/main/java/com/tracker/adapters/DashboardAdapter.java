package com.tracker.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.tracker.artisanengine.R;
import com.tracker.models.DashboardOption;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class DashboardAdapter extends ArrayAdapter<DashboardOption> {

    private ArrayList<DashboardOption> options;
    private Context context;

    public DashboardAdapter(Context context, ArrayList<DashboardOption> options) {
        super(context, 0, options);
        this.context = context;
        this.options = options;
    }

    @Override
    public int getCount() {
        return super.getCount();
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if(convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.dashboard_grid_item, parent, false);
        }
        ImageView optionImageView = (ImageView) convertView.findViewById(R.id.optionImage);
        TextView optionTextView = (TextView) convertView.findViewById(R.id.optionName);
        optionImageView.setImageResource(options.get(position).getImage());
        optionTextView.setText(options.get(position).getOptionName());
        return convertView;
    }
}
