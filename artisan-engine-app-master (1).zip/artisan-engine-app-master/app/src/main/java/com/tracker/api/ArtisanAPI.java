package com.tracker.api;

import com.tracker.responses.RegistrationResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ArtisanAPI {

    @FormUrlEncoded
    @POST("artisans")
    Call<RegistrationResponse> register(@Field("name") String name,
                                        @Field("email") String email,
                                        @Field("password") String password,
                                        @Field("confirm_password") String confirmPassword,
                                        @Field("artisan_type_id") int artisanTypeId,
                                        @Field("suburb_id") int suburbId,
                                        @Field("latitude") double latitude,
                                        @Field("longitude") double longitude,
                                        @Field("firebase_token") String firebaseToken);

    @FormUrlEncoded
    @POST("artisans/login")
    Call<RegistrationResponse> login(@Field("email") String email,
                                     @Field("password") String password,
                                     @Field("firebase_token") String firebaseToken);

}
