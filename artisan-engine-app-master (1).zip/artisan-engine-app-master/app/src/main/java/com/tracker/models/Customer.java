package com.tracker.models;

public class Customer {

    private String name;
    private String email;
    private User user;

    public String getEmail() {
        return email;
    }

    public String getName() {
        return name;
    }

    public User getUser() {
        return user;
    }
}
