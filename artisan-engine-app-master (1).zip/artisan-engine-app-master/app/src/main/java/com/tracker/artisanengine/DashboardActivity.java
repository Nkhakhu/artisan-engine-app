package com.tracker.artisanengine;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;

import com.tracker.adapters.DashboardAdapter;
import com.tracker.models.DashboardOption;

import java.util.ArrayList;

public class DashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        initialiseViewComponents();
    }

    private void initialiseViewComponents() {
        GridView dashboardGrid = (GridView) findViewById(R.id.dashboardGrid);
        TextView creditsTxt = (TextView) findViewById(R.id.credits);
        SharedPreferences preferencesGet = getSharedPreferences("KEY", Context.MODE_PRIVATE);
        String credits = preferencesGet.getString("creditsKEY", null);
        creditsTxt.setText(credits + " Credits");
        ArrayList<DashboardOption> options = new ArrayList<DashboardOption>();
        DashboardOption leadsOption = new DashboardOption(R.drawable.leads, "Raw Leads");
        DashboardOption creditsOption = new DashboardOption(R.drawable.coins, "Credits");
        DashboardOption completedJobsOption = new DashboardOption(R.drawable.leads_purchased, "Purchased Leads");
        DashboardOption portfolioOption = new DashboardOption(R.drawable.portifolio, "Portfolio");
        DashboardOption reviewOption = new DashboardOption(R.drawable.review, "Reviews");
        DashboardOption servicesOption = new DashboardOption(R.drawable.services, "Services");
        options.add(leadsOption);
        options.add(creditsOption);
        options.add(completedJobsOption);
        options.add(portfolioOption);
        options.add(reviewOption);
        options.add(servicesOption);
        DashboardAdapter dashboardAdapter = new DashboardAdapter(getApplicationContext(), options);
        dashboardGrid.setAdapter(dashboardAdapter);
        dashboardGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                DashboardOption selectedOption = (DashboardOption) options.get(position);
                if(selectedOption.getOptionName().equals("Raw Leads")) {
                    Intent getLeadsIntent = new Intent(getApplicationContext(), GetLeadListActivity.class);
                    startActivity(getLeadsIntent);
                } else if(selectedOption.getOptionName().equals("Credits")) {
                    Intent creditsIntent = new Intent(getApplicationContext(), CreditsActivity.class);
                    startActivity(creditsIntent);
                } else if(selectedOption.getOptionName().equals("Portfolio")) {
                    Intent portfolioIntent = new Intent(getApplicationContext(), GetPortfolioItemsActivity.class);
                    startActivity(portfolioIntent);
                } else if(selectedOption.getOptionName().equals("Purchased Leads")) {
                    Intent purchasedLeadsIntent = new Intent(getApplicationContext(), PurchasedLeadsActivity.class);
                    startActivity(purchasedLeadsIntent);
                }
            }
        });
        String name = preferencesGet.getString("nameKEY", null);
        String salutation = "Welcome, " + name;
        TextView nameTxtView = findViewById(R.id.name);
        nameTxtView.setText(salutation);
    }
}