package com.tracker.models;

import java.io.Serializable;

public class ArtisanType implements Serializable {

    private String artisanTypeName;
    private int artisanTypeId;
    private int artisanTypeImage;

    public ArtisanType(String artisanTypeName, int artisanTypeId) {
        this.artisanTypeName = artisanTypeName;
        this.artisanTypeId = artisanTypeId;
    }

    public ArtisanType(String artisanTypeName, int artisanTypeId, int image) {
        this.artisanTypeName = artisanTypeName;
        this.artisanTypeId = artisanTypeId;
        this.artisanTypeImage = image;
    }

    public String getArtisanTypeName() {
        return this.artisanTypeName;
    }

    public void setArtisanTypeImage(int image) {
        this.artisanTypeImage = image;
    }

    public int getImage() {
        return this.artisanTypeImage;
    }

    public void setArtisanTypeName(String artisanTypeName) {
        this.artisanTypeName = artisanTypeName;
    }

    public int getArtisanTypeId() {
        return this.artisanTypeId;
    }

    public void setArtisanTypeId(int artisanTypeId) {
        this.artisanTypeId = artisanTypeId;
    }

    @Override
    public String toString() {
        return artisanTypeName;
    }
}
