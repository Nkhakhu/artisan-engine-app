package com.tracker.api;

import com.tracker.responses.GetLeadListResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;

public interface LeadAPI {

    @GET("leads")
    Call<GetLeadListResponse> getLeads(@Header("Authorization") String token);
}
