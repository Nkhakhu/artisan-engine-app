package com.tracker.artisanengine;

import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.tracker.api.PortfolioAPI;
import com.tracker.api.RetrofitClientInstance;
import com.tracker.responses.CreatePortfolioResponse;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class CreatePortfolioActivity extends AppCompatActivity {

    private final int PICK_IMAGE_MULTIPLE = 1;
    private List<byte[]> imageBytes;
    private Uri filePath;
    private ImageView image1, image2, image3, image4, image5, image6, image7, image8;
    private Button submitButton;
    private boolean image1set, image2set, image3set, image4set, image5set, image6set, image7set, image8set = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_portifolio);
        initializeView();
    }

    private void initializeView() {
        image1 = findViewById(R.id.image1);
        image2 = findViewById(R.id.image2);
        image3 = findViewById(R.id.image3);
        image4 = findViewById(R.id.image4);
        image5 = findViewById(R.id.image5);
        image6 = findViewById(R.id.image6);
        image7 = findViewById(R.id.image7);
        image8 = findViewById(R.id.image8);

        image1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileChooser();
            }
        });

        image2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileChooser();
            }
        });

        image3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileChooser();
            }
        });

        image4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileChooser();
            }
        });
        image5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileChooser();
            }
        });

        image6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileChooser();
            }
        });

        image7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileChooser();
            }
        });

        image8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileChooser();
            }
        });

        Button submitButton = findViewById(R.id.submit);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText titleTxt = findViewById(R.id.title);
                EditText descriptionTxt = findViewById(R.id.description);
                String title = titleTxt.getText().toString();
                String description = descriptionTxt.getText().toString();
                SharedPreferences preferencesGet = getSharedPreferences("KEY", Context.MODE_PRIVATE);
                String jwtToken = preferencesGet.getString("tokenKEY", null);
                Retrofit retrofit = RetrofitClientInstance.getRetrofitInstance();
                PortfolioAPI portfolioAPI = retrofit.create(PortfolioAPI.class);
                ArrayList<MultipartBody.Part> images = new ArrayList<MultipartBody.Part>();
                if (imageBytes != null) {
                    for (byte[] b : imageBytes) {
                        RequestBody requestFile = RequestBody.create(MediaType.parse("image/jpeg"), b);
                        MultipartBody.Part body = MultipartBody.Part.createFormData("images[]", "image.jpg", requestFile);
                        images.add(body);
                    }
                } else {
                    Toast.makeText(getApplicationContext(),
                            "Please select at least one image",
                            Toast.LENGTH_LONG)
                            .show();
                    return;
                }

                final ProgressDialog progressDialog;
                progressDialog = new ProgressDialog(CreatePortfolioActivity.this);
                progressDialog.setMax(100);
                progressDialog.setTitle("Progress");
                progressDialog.setMessage("Processing....");
                progressDialog.show();
                portfolioAPI.createPortfolio(title, description, images, "Bearer " + jwtToken).enqueue(new Callback<CreatePortfolioResponse>() {
                    @Override
                    public void onResponse(Call<CreatePortfolioResponse> call, Response<CreatePortfolioResponse> response) {
                        if (response.body().isSuccess()) {
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(),
                                    "Portfolio created successfully!",
                                    Toast.LENGTH_LONG)
                                    .show();
                            Intent getPortfoliosIntent = new Intent(getApplicationContext(), GetPortfolioItemsActivity.class);
                            startActivity(getPortfoliosIntent);
                        }
                    }

                    @Override
                    public void onFailure(Call<CreatePortfolioResponse> call, Throwable t) {

                    }
                });
            }
        });
    }

    private void showFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_MULTIPLE);
    }

    public byte[] getBytes(InputStream is) throws IOException {
        ByteArrayOutputStream byteBuff = new ByteArrayOutputStream();
        int buffSize = 1024;
        byte[] buff = new byte[buffSize];
        int len = 0;
        while ((len = is.read(buff)) != -1) {
            byteBuff.write(buff, 0, len);
        }

        return byteBuff.toByteArray();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_MULTIPLE && resultCode == RESULT_OK && data != null) {
            imageBytes = new ArrayList<byte[]>();
            if (data.getClipData() != null) {
                ClipData mClipData = data.getClipData();
                for (int i = 0; i < mClipData.getItemCount(); i++) {
                    ClipData.Item item = mClipData.getItemAt(i);
                    Uri uri = item.getUri();
                    try {
                        InputStream is = getContentResolver().openInputStream(uri);
                        imageBytes.add(getBytes(is));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    if (!image1set) {
                        image1.setImageURI(uri);
                        image1set = true;
                    } else if (!image2set) {
                        image2.setImageURI(uri);
                        image2set = true;
                    } else if (!image3set) {
                        image3.setImageURI(uri);
                        image3set = true;
                    } else if (!image4set) {
                        image4.setImageURI(uri);
                        image4set = true;
                    } else if (!image5set) {
                        image5.setImageURI(uri);
                        image5set = true;
                    } else if (!image6set) {
                        image6.setImageURI(uri);
                        image6set = true;
                    } else if (!image7set) {
                        image7.setImageURI(uri);
                        image7set = true;
                    } else if (!image8set) {
                        image8.setImageURI(uri);
                        image8set = true;
                    }
                }
            } else {
                filePath = data.getData();
                if (!image1set) {
                    image1.setImageURI(filePath);
                    image1set = true;
                } else if (!image2set) {
                    image2.setImageURI(filePath);
                    image2set = true;
                } else if (!image3set) {
                    image3.setImageURI(filePath);
                    image3set = true;
                } else if (!image4set) {
                    image4.setImageURI(filePath);
                    image4set = true;
                } else if (!image5set) {
                    image5.setImageURI(filePath);
                    image5set = true;
                } else if (!image6set) {
                    image6.setImageURI(filePath);
                    image6set = true;
                } else if (!image7set) {
                    image7.setImageURI(filePath);
                    image7set = true;
                } else if (!image8set) {
                    image8.setImageURI(filePath);
                    image8set = true;
                }
            }
        }
    }
}