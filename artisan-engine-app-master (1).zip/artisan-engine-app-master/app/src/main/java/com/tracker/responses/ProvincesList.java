package com.tracker.responses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.tracker.models.Province;

import java.util.ArrayList;

public class ProvincesList {

    @SerializedName("data")
    @Expose
    private ArrayList<Province> provinces;

    public ArrayList<Province> getProvinces() {
        return this.provinces;
    }
}
