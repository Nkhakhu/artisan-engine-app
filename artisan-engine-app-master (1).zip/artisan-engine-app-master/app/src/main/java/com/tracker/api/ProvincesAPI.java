package com.tracker.api;

import com.tracker.responses.ProvincesList;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ProvincesAPI {

    @GET("provinces")
    Call<ProvincesList> getProvinces();
}
