package com.tracker.models;

public class DashboardOption {

    private int image;
    private  String optionName;

    public DashboardOption(int image, String name) {
        this.image = image;
        this.optionName = name;
    }

    public int getImage() {
        return this.image;
    }

    public String getOptionName() {
        return this.optionName;
    }
}
