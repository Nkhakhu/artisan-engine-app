package com.tracker.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.tracker.artisanengine.R;
import com.tracker.models.PortfolioItem;

import java.util.ArrayList;

import androidx.annotation.NonNull;

public class PortfolioListAdapter extends ArrayAdapter<PortfolioItem> {

    private ArrayList<PortfolioItem> portfolioItems;
    private Context context;

    public PortfolioListAdapter(@NonNull Context context, ArrayList<PortfolioItem> portfolioItems) {
        super(context, 0, portfolioItems);
        this.context = context;
        this.portfolioItems = portfolioItems;
    }

    @Override
    public int getCount() {
        return super.getCount();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.portfolio_item_list, parent, false);
            String baseUrl = convertView.getContext().getResources().getString(R.string.images_folder);
            ImageView portfolioImageView = (ImageView) convertView.findViewById(R.id.portfolio_image);
            Glide.with(getContext())
                    .load(baseUrl + portfolioItems.get(position).getPortfolioItemImages().get(0).getImageUrl())
                    .into(portfolioImageView);
            TextView titleTextView = (TextView) convertView.findViewById(R.id.portfolio_title);
            titleTextView.setText(portfolioItems.get(position).getTitle());
            TextView descriptionTxt = (TextView) convertView.findViewById(R.id.portfolio_description);
            descriptionTxt.setText(portfolioItems.get(position).getDescription());
        }
        return convertView;
    }
}
