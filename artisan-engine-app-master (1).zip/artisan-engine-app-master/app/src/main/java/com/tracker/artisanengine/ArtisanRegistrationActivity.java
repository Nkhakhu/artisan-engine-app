package com.tracker.artisanengine;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;
import com.tracker.api.ArtisanAPI;
import com.tracker.api.ProvincesAPI;
import com.tracker.api.RetrofitClientInstance;
import com.tracker.models.ArtisanType;
import com.tracker.models.Province;
import com.tracker.responses.ProvincesList;
import com.tracker.responses.RegistrationResponse;
import com.tracker.models.Suburb;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class ArtisanRegistrationActivity extends AppCompatActivity {

    private Spinner artisanTypeSpinner, provincesSpinner, suburbsSpinner;
    private ArrayList<ArtisanType> artisanTypes;
    private ArrayList<Province> provinces;
    private String firebaseToken;
    private ArrayList<Suburb> suburbs;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        getFirebaseToken();
        initComponents();
        fetchProvincesAndPopulateSpinner();
    }

    private void fetchProvincesAndPopulateSpinner()
    {
        provinces = new ArrayList<Province>();
        suburbs = new ArrayList<Suburb>();
        Retrofit retrofit = RetrofitClientInstance.getRetrofitInstance();
        ProvincesAPI provincesAPI = retrofit.create(ProvincesAPI.class);
        final ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(ArtisanRegistrationActivity.this);
        progressDialog.setMax(100);
        progressDialog.setTitle("Progress");
        progressDialog.setMessage("Fetching Data....");
        progressDialog.show();
        provincesAPI.getProvinces().enqueue(new Callback<ProvincesList>() {
            @Override
            public void onResponse(Call<ProvincesList> call, Response<ProvincesList> response) {
                provinces = response.body().getProvinces();
                Spinner provincesSpinner = findViewById(R.id.provinces);
                ArrayAdapter<Province> provincesDataAdapter = new ArrayAdapter<Province>(getApplicationContext(),
                        android.R.layout.simple_spinner_dropdown_item,
                        provinces);
                provincesDataAdapter.setDropDownViewResource(R.layout.custom_spinner_item);
                provincesSpinner.setAdapter(provincesDataAdapter);
                progressDialog.dismiss();
            }

            @Override
            public void onFailure(Call<ProvincesList> call, Throwable t) {
                progressDialog.dismiss();
            }
        });
    }

    protected void initComponents() {
        EditText nameEditTxt = findViewById(R.id.name);
        EditText emailEditTxt = findViewById(R.id.email);
        EditText passwordTxt = findViewById(R.id.password);
        EditText confirmPasswordTxt = findViewById(R.id.confirm_password);
        EditText addressTxt = findViewById(R.id.address);
        provincesSpinner = (Spinner) findViewById(R.id.provinces);
        provincesSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Province selectedProvince = provinces.get(position);
                ArrayAdapter<Suburb> suburbsAdapter = new ArrayAdapter<Suburb>(
                        getApplicationContext(),
                        android.R.layout.simple_spinner_dropdown_item,
                        selectedProvince.getSuburbs()
                );
                suburbsSpinner.setAdapter(suburbsAdapter);
                suburbsAdapter.setDropDownViewResource(R.layout.custom_spinner_item);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        TextView artisanLoginLink = findViewById(R.id.artisan_login_link);
        artisanLoginLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent artisanLoginActivity = new Intent(getApplicationContext(), ArtisanLoginActivity.class);
                startActivity(artisanLoginActivity);
            }
        });
        artisanTypeSpinner = findViewById(R.id.artisan_types);
        suburbsSpinner = findViewById(R.id.suburb);
        artisanTypes = createArtisanTypes();
        ArrayAdapter<ArtisanType> dataAdapter = new ArrayAdapter<ArtisanType>(
                getApplicationContext(),
                android.R.layout.simple_spinner_dropdown_item,
                artisanTypes
        );
        artisanTypeSpinner.setAdapter(dataAdapter);
        dataAdapter.setDropDownViewResource(R.layout.custom_spinner_item);
        ArrayAdapter<Province> provincesDataAdapter = new ArrayAdapter<Province>(
                getApplicationContext(),
                android.R.layout.simple_spinner_dropdown_item,
                createProvinces()
        );
        Button button = findViewById(R.id.submit);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String address = addressTxt.getText().toString();
                String name = nameEditTxt.getText().toString();
                String email = emailEditTxt.getText().toString();
                String password = passwordTxt.getText().toString();
                String confirmPassword = confirmPasswordTxt.getText().toString();
                Province province = (Province) provincesSpinner.getSelectedItem();
                Suburb suburb = (Suburb) suburbsSpinner.getSelectedItem();
                ArtisanType artisanType = (ArtisanType) artisanTypeSpinner.getSelectedItem();
                Address location = reverseGeocodeAddress(address + " " + suburb.getSuburbName() + " "
                        + province.getProvinceName()
                        + " South Africa");
                if (address.equals("")) {
                    Toast.makeText(getApplicationContext(),
                            "Please enter a valid address",
                            Toast.LENGTH_LONG)
                            .show();
                    return;
                } else if (name.equals("")) {
                    Toast.makeText(getApplicationContext(),
                            "Please enter your name",
                            Toast.LENGTH_LONG)
                            .show();
                    return;
                } else if (email.equals("")) {
                    Toast.makeText(getApplicationContext(),
                            "Please enter a valid email address",
                            Toast.LENGTH_LONG)
                            .show();
                    return;
                } else if (password.equals("")) {
                    Toast.makeText(getApplicationContext(),
                            "Please enter a password",
                            Toast.LENGTH_LONG)
                            .show();
                    return;
                }
                submitRegistrationRequest(
                        name,
                        email,
                        password,
                        confirmPassword,
                        artisanType.getArtisanTypeId(),
                        suburb.getSuburbId(),
                        location.getLatitude(),
                        location.getLongitude()
                );
            }
        });
    }

    private void getFirebaseToken() {
        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(new OnCompleteListener<String>() {
                    @Override
                    public void onComplete(@NonNull Task<String> task) {
                        if (!task.isSuccessful()) {
                            return;
                        }
                        firebaseToken = task.getResult();
                    }
                });
    }

    private void submitRegistrationRequest(String name, String email, String password, String confirmPassword, int artisanTypeId, int suburbId, double latitude, double longitude) {
        Retrofit retrofit = RetrofitClientInstance.getRetrofitInstance();
        ArtisanAPI artisanAPI = retrofit.create(ArtisanAPI.class);
        final ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(this);
        progressDialog.setMax(100);
        progressDialog.setTitle("Progress");
        progressDialog.setMessage("Fetching Data....");
        progressDialog.show();
        artisanAPI.register(name, email, password, confirmPassword, artisanTypeId, suburbId, latitude, longitude, firebaseToken).enqueue(
                new Callback<RegistrationResponse>() {
                    @Override
                    public void onResponse(Call<RegistrationResponse> call, Response<RegistrationResponse> response) {
                        if (response.code() == 201) {
                            SharedPreferences preferencesPut = getSharedPreferences("KEY", Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor = preferencesPut.edit();
                            editor.putString("tokenKEY", response.body().getToken());
                            editor.putString("emailKEY", email);
                            editor.putString("nameKEY", name);
                            editor.putString("creditsKEY", Integer.toString(response.body().getArtisan().getCredits()));
                            editor.putString("userTypeKEY", "Artisan");
                            editor.putBoolean("done", true);
                            editor.apply();
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), "Registration successful!", Toast.LENGTH_LONG)
                                    .show();
                            Intent dashBoardIntent = new Intent(getApplicationContext(), DashboardActivity.class);
                            startActivity(dashBoardIntent);
                        } else if (response.code() == 422) {
                            try {
                                ArrayList<String> errorMessages = new ArrayList<String>();
                                String errorResponseBody = response.errorBody().string();
                                JSONObject bodyObj = new JSONObject(errorResponseBody);
                                JSONArray errors = bodyObj.getJSONArray("errors");
                            } catch (IOException | JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<RegistrationResponse> call, Throwable t) {
                        Log.d("TAG", t.getMessage());
                    }
                }
        );
    }

    protected Address reverseGeocodeAddress(String address) {
        Geocoder geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());
        List<Address> addresses = null;
        try {
            addresses = geocoder.getFromLocationName(address, 1);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return addresses.get(0);
    }

    protected ArrayList<ArtisanType> createArtisanTypes() {
        artisanTypes = new ArrayList<ArtisanType>();
        artisanTypes.add(new ArtisanType("Plumber", 1));
        artisanTypes.add(new ArtisanType("Electrician", 2));
        artisanTypes.add(new ArtisanType("Painter", 3));
        artisanTypes.add(new ArtisanType("Carpenter", 4));
        artisanTypes.add(new ArtisanType("Welder", 5));
        artisanTypes.add(new ArtisanType("Construction", 6));
        artisanTypes.add(new ArtisanType("Locksmith", 7));
        artisanTypes.add(new ArtisanType("Air Conditioning & Refrigerator", 8));
        artisanTypes.add(new ArtisanType("Furniture & Upholstery", 9));
        return artisanTypes;
    }

    protected ArrayList<Province> createProvinces() {
        provinces = new ArrayList<Province>();
        Province province = new Province("Gauteng");
        province.getSuburbs().add(new Suburb("Sandton", 1, "Gauteng"));
        province.getSuburbs().add(new Suburb("Alexandra", 2, "Gauteng"));
        provinces.add(province);
        return provinces;
    }
}