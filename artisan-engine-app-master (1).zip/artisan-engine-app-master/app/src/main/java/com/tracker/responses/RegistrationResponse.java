package com.tracker.responses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.tracker.models.Artisan;

public class RegistrationResponse {

    @SerializedName("jwt_token")
    @Expose
    private String token;

    @SerializedName("success")
    @Expose
    private boolean success;

    @SerializedName("artisan")
    @Expose
    private Artisan artisan;

    public String getToken() {
        return token;
    }

    public Artisan getArtisan() {
        return artisan;
    }

    public boolean getSuccess() {
        return success;
    }
}
