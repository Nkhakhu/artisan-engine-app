package com.tracker.models;

public class PortfolioItemImage {

    private String image_url;

    public String getImageUrl()
    {
        return this.image_url;
    }
}
