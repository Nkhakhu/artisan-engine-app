package com.tracker.artisanengine;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import com.tracker.adapters.PortfolioListAdapter;
import com.tracker.api.PortfolioAPI;
import com.tracker.api.RetrofitClientInstance;
import com.tracker.models.PortfolioItem;
import com.tracker.responses.GetPortfolioResponse;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class GetPortfolioItemsActivity extends AppCompatActivity {

    private ListView portfolioListItem;
    private ArrayList<PortfolioItem> portfolioItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_portfolio_items);
        portfolioListItem = (ListView) findViewById(R.id.portfolioItemsList);
        portfolioItems = new ArrayList<PortfolioItem>();
        Button createNewPortfolioButton = (Button) findViewById(R.id.createPortfolio);
        createNewPortfolioButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent createPortfolioIntent = new Intent(getApplicationContext(), CreatePortfolioActivity.class);
                startActivity(createPortfolioIntent);
            }
        });
        getPortfolioItems();
    }

    private void getPortfolioItems() {
        Retrofit retrofit = RetrofitClientInstance.getRetrofitInstance();
        PortfolioAPI portfolioAPI = retrofit.create(PortfolioAPI.class);
        SharedPreferences preferencesGet = getSharedPreferences("KEY", Context.MODE_PRIVATE);
        String jwtToken = preferencesGet.getString("tokenKEY", null);
        final ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(GetPortfolioItemsActivity.this);
        progressDialog.setMax(100);
        progressDialog.setTitle("Progress");
        progressDialog.setMessage("Fetching data....");
        progressDialog.show();
        portfolioAPI.getPortfolioItems("Bearer " + jwtToken).enqueue(new Callback<GetPortfolioResponse>() {
            @Override
            public void onResponse(Call<GetPortfolioResponse> call, Response<GetPortfolioResponse> response) {
                portfolioItems = response.body().getPortfolioItems();
                PortfolioListAdapter portfolioListAdapter = new PortfolioListAdapter(getApplicationContext(), portfolioItems);
                portfolioListItem.setAdapter(portfolioListAdapter);
                progressDialog.dismiss();
            }

            @Override
            public void onFailure(Call<GetPortfolioResponse> call, Throwable t) {

            }
        });
    }
}