package com.tracker.models;

import java.util.ArrayList;
import java.util.Comparator;

public class Province {

    public static Comparator<Province> ALPHABETICAL_ORDER = new Comparator<Province>() {

        @Override
        public int compare(Province province1, Province province2) {
            int res = String.CASE_INSENSITIVE_ORDER.compare(province1.getProvinceName(), province2.getProvinceName());
            if (res == 0) {
                res = province1.getProvinceName().compareTo(province2.getProvinceName());
            }
            return res;
        }
    };
    private final String province_name;
    private ArrayList<Suburb> suburbs = new ArrayList<Suburb>();

    public Province(String province_name, ArrayList<Suburb> suburbs) {
        this.province_name = province_name;
        this.suburbs = suburbs;
    }

    public Province(String provinceName) {
        this.province_name = provinceName;
    }

    public String getProvinceName() {
        return this.province_name;
    }

    public ArrayList<Suburb> getSuburbs() {
        return this.suburbs;
    }

    public void setSuburbs(ArrayList<Suburb> suburbs) {
        this.suburbs = suburbs;
    }

    @Override
    public String toString() {
        return this.province_name;
    }
}
